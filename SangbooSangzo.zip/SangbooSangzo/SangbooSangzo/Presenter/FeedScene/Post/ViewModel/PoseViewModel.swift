//
//  PoseViewModel.swift
//  SangbooSangzo
//
//  Created by Deokhun KIM on 4/16/24.
//

import Foundation

import RxCocoa
import RxSwift

final class PostViewModel: ViewModel {
    
    struct Input {
        
    }
    
    struct Output {
        
    }
    
    var disposeBag = DisposeBag()
    
    func transform(_ input: Input) -> Output {
        
        return Output()
    }
}
