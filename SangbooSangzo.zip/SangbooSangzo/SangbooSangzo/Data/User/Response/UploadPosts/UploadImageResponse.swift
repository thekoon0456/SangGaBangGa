//
//  UploadImageResponse.swift
//  SangbooSangzo
//
//  Created by Deokhun KIM on 4/12/24.
//

import Foundation

struct UploadImageResponse: Decodable {
    let files: [String]
}

