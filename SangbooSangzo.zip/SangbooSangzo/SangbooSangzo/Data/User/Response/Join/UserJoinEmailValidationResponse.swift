//
//  UserJoinEmailValidationResponse.swift
//  SangbooSangzo
//
//  Created by Deokhun KIM on 4/12/24.
//

import Foundation

struct UserJoinEmailValidationResponse: Decodable {
    let message: String
}
