//
//  RefreshTokenResponse.swift
//  SangbooSangzo
//
//  Created by Deokhun KIM on 4/12/24.
//

import Foundation

struct RefreshTokenResponse: Decodable {
    let accessToken: String
}
