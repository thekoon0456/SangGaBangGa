//
//  UserJoinEmailValidationRequest.swift
//  SangbooSangzo
//
//  Created by Deokhun KIM on 4/12/24.
//

import Foundation

struct UserJoinEmailValidationRequest: Encodable {
    let email: String
}
