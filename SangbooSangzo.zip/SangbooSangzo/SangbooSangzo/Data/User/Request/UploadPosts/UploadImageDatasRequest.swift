//
//  UploadImageDatasQuery.swift
//  SangbooSangzo
//
//  Created by Deokhun KIM on 4/12/24.
//

import Foundation

struct UploadImageDatasRequest: Encodable {
    let datas: [Data]
}
