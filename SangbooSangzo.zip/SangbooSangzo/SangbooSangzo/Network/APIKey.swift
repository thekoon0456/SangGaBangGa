//
//  APIKey.swift
//  SangbooSangzo
//
//  Created by Deokhun KIM on 4/11/24.
//

import Foundation

enum APIKey {
    static let baseURL = "http://lslp.sesac.kr:31222"
    static let tempURL = "http://lslp.sesac.kr:38282"
    static let sesacKey = "5UcCSai73v"
}
