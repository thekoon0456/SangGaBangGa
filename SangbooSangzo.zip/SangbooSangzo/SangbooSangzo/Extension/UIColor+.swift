//
//  UIColor+.swift
//  SangbooSangzo
//
//  Created by Deokhun KIM on 4/15/24.
//

import UIKit

extension UIColor {
    static let tintColor = UIColor.systemPurple
}
